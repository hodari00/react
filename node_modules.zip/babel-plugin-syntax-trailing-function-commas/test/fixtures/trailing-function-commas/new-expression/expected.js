new Foo(a, b);
