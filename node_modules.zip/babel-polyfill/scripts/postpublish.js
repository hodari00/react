rm(__dirname + "/../browser.js");
